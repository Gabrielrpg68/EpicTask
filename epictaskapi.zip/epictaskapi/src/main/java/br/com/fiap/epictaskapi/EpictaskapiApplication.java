package br.com.fiap.epictaskapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpictaskapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpictaskapiApplication.class, args);
	}

}
