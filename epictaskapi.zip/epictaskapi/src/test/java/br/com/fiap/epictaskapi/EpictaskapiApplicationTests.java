package br.com.fiap.epictaskapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpictaskapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
